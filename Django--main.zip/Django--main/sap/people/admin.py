from django.contrib import admin
from people.models import People, Domicile

# Register your models here.
admin.site.register(People)
admin.site.register(Domicile)